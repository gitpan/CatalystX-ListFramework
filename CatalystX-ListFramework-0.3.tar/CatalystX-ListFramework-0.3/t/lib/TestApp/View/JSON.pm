package TestApp::View::JSON;

use strict;
use base 'Catalyst::View::JSON';

1;
